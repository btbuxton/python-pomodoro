import pomodoro.tkapp

pomodoro.tkapp.main()